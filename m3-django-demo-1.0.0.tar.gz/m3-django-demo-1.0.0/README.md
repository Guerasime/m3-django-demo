# M3 Django Demo Project

Проект демонстрирует интеграцию Django с M3 framework и Objectpack для CRUD операций.

## Установка

```bash
pip install m3-django-demo